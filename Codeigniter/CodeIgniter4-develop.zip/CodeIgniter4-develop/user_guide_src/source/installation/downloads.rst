#######################
Downloading CodeIgniter
#######################

-  `CodeIgniter v4.0.0-dev (Upcoming version) <https://codeload.github.com/bcit-ci/CodeIgniter4/zip/develop>`_

******
GitHub
******

`Git <http://git-scm.com/about>`_ is a distributed version control system.

Public Git access is available at `GitHub <https://github.com/bcit-ci/CodeIgniter4>`_.
Please note that while every effort is made to keep this code base
functional, we cannot guarantee the functionality of code taken from
the develop branch.

Stable versions are also available via `GitHub Releases <https://github.com/bcit-ci/CodeIgniter4/releases>`_.