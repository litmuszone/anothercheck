##########
Pagination
##########

CodeIgniter provides a very simple, but flexible pagination library that is simple to theme, works with the model,
and capable of supporting multiple paginators on a single page.

*******************
Loading the Library
*******************

Like all services in CodeIgniter, it can be loaded via ``Config\Services``, though you usually will not need
to load it manually::

    $pager = \Config\Services::pager();

***************************
Paginating Database Results
***************************

In most cases, you will be using the Pager library in order to paginate results that you retrieve from the database.
When using the :doc:`Model </database/model>` class, you can use its built-in ``paginate()`` method to automatically
retrieve the current batch of results, as well as setup the Pager library so it's ready to use in your controllers.
It even reads the current page it should display from the current URL via a ``page=X`` query variable.

To provide a paginated list of users in your application, your controller's method would look something like::

    class UserController extends Controller
    {
        public function index()
        {
            $model = new \App\Models\UserModel();

            $data = [
                'users' => $model->paginate(10),
                'pager' => $model->pager
            ];

            echo view('users/index', $data);
        }
    }

In this example, we first create a new instance of our UserModel. Then we populate the data to sent to the view.
The first element is the results from the database, **users**, which is retrieved for the correct page, returning
10 users per page. The second item that must be sent to the view is the Pager instance itself. As a convenience,
the Model will hold on to the instance it used and store it in the public class variable, **$pager**. So, we grab
that and assign it to the $pager variable in the view.

Within the view, we then need to tell it where to display the resulting links::

    <?= $pager->links() ?>

And that's all it takes. The Pager class will render a series of links that are compatible with the Boostrap CSS
framework by default. It will have First and Last page links, as well as Next and Previous links for any pages more
than two pages on either side of the current page.

If you prefer a simpler output, you can use the ``simpleLinks()`` method, which only uses "Older" and "Newer" links,
instead of the details pagination links::

    <?= $pager->simpleLinks() ?>


Behind the scenes, the library loads a view file that determines how the links are formatted, making it simple to
modify to your needs. See below for details on how to completely customize the output.

Paginating Multiple Results
===========================

If you need to provide links from two different result sets, you can pass group names to most of the pagination
methods to keep the data separate::

    // In the Controller
    public function index()
    {
        $userModel = new \App\Models\UserModel();
        $pageModel = new \App\Models\PageModel();

        $data = [
            'users' => $userModel->paginate(10, 'group1'),
            'pages' => $pageModel->paginate(15, 'group2'),
            'pager' => $userModel->pager
        ];

        echo view('users/index', $data);
    }

    // In the views:
    <?= $pager->links('group1') ?>
    <?= $pager->simpleLinks('group2') ?>

Manual Pagination
=================

You may find times where you just need to create pagination based on known data. You can create links manually
with the ``makeLinks()`` method, which takes the current page, the amount of results per page, and
the total number of items as the first, second, and third parameters, respectively::

    <?= $pager->makeLinks($page, $perPage, $total) ?>

This will, by default, display the links in the normal manner, as a series of links, but you can change the display
template used by passing in the name of the template as the fourth parameter. More details can be found in the following
sections.
::

    <?= $pager->makeLinks($page, $perPage, $total, 'template_name') ?>

*********************
Customizing the Links
*********************

View Configuration
==================

When the links are rendered out to the page, they use a view file to describe the HTML. You can easily change the view
that is used by editing **application/Config/Pager.php**::

    public $templates = [
		'default_full'   => 'CodeIgniter\Pager\Views\default_full',
		'default_simple' => 'CodeIgniter\Pager\Views\default_simple'
	];

This setting stores the alias and :doc:`namespaced view paths </general/views#namespaced-views>` for the view that
should be used. The *default_full* and *default_simple* views are used for the ``links()`` and ``simpleLinks()``
methods, respectively. To change the way those are displayed application-wide, you could assign a new view here.

For example, say you create a new view file that works with the Foundation CSS framework, instead of Bootstrap, and
you place that file at **application/Views/Pagers/foundation_full.php**. Since the **application** directory is
namespaced as ``App``, and all directories underneath it map directly to segments of the namespace, you can locate
the view file through it's namespace::

    'default_full'   => 'App\Views\Pagers\foundation_full',

Since it is under the standard **application/Views** directory, though, you do not need to namespace it since the
``view()`` method will locate. In that case, you can simple give the sub-directory and file name::

    'default_full'   => 'Pagers/foundation_full',

Once you have created the view and set it in the configuration, it will automatically be used. You don't have to
just replace the existing templates. You can create as many additional templates as you need in the configuration
file. A common situation would be needing different styles for the frontend and the backend of your application.
::

    public $templates = [
		'default_full'   => 'CodeIgniter\Pager\Views\default_full',
		'default_simple' => 'CodeIgniter\Pager\Views\default_simple',
		'front_full'     => 'App\Views\Pagers\foundation_full',
	];

Once configured, you can specify it as a the last parameter in the ``links()``, ``simpleLinks()``, and ``makeLinks()``
methods::

    <?= $pager->links('group1', 'front_full') ?>
    <?= $pager->simpleLinks('group2', 'front_full') ?>
    <?= $pager->makeLinks($page, $perPage, $total, 'front_full') ?>

Creating the View
=================

When you create a new view, you only need to create the code that is needed for creating the pagination links themselves.
You should never create unneccessary wrapping divs since it might be used in multiple places and you only limit their
usefullness. It is easiest to demonstrate creating a new view by showing you the existing default_full template::

    <?php $pager->setSurroundCount(2) ?>

    <nav aria-label="Page navigation">
        <ul class="pagination">
            <?php if ($pager->hasPrevious()) : ?>
            <li>
				<a href="<?= $pager->getFirst() ?>" aria-label="First">
					<span aria-hidden="true">First</span>
				</a>
			</li>
            <li>
                <a href="<?= $pager->getPrevious() ?>" aria-label="Previous">
                    <span aria-hidden="true">&laquo;</span>
                </a>
            </li>
            <?php endif ?>

            <?php foreach ($pager->links() as $link) : ?>
                <li <?= $link['active'] ? 'class="active"' : '' ?>>
                    <a href="<?= $link['uri'] ?>">
                        <?= $link['title'] ?>
                    </a>
                </li>
            <?php endforeach ?>

            <?php if ($pager->hasNext()) : ?>
                <li>
                    <a href="<?= $pager->getNext() ?>" aria-label="Previous">
                        <span aria-hidden="true">&raquo;</span>
                    </a>
                </li>
                <li>
					<a href="<?= $pager->getLast() ?>" aria-label="Last">
						<span aria-hidden="true">Last</span>
					</a>
				</li>
            <?php endif ?>
        </ul>
    </nav>

**setSurroundCount()**

In the first line, the ``setSurroundCount()`` method specifies that we want to show two links to either side of
the current page link. The only parameter that it accepts is the number of links to show.

**hasPrevious()**
**hasNext()**

These methods return a boolean true if it has more links than can be displayed on either side of the current page,
based on the value passed to ``setSurroundCount``. For example, let's say we have 20 pages of data. The current
page is page 3. If the surround count is 2, then the following links would show up in the list: 1, 2, 3, 4, and 5.
Since the first link displayed is page one, ``hasPrevious()`` would return **false** since there is no page zero. However,
``hasNext()`` would return **true** since there are 15 additional pages of results after page five.

**getPrevious()**
**getNext()**

These methods return the URL for the previous or next pages of results on either side of the numbered links. See the
previous paragraph for a full explanation.

**getFirst()**
**getLast()**

Much like ``getPrevious()`` and ``getNext()``, these methods return links to the first and last pages in the
result set.

**links()**

Returns an array of data about all of the numbered links. Each link's array contains the uri for the link, the
title, which is just the number, and a boolean that tells whether the link is the current/active link or not::

	$link = [
		'active' => false,
		'uri'    => 'http://example.com/foo?page=2',
		'title'  => 1
	];
