#####################
Handling Transactions
#####################

TODO
