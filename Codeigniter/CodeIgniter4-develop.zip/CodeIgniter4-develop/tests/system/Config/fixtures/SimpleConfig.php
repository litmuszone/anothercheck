<?php

class SimpleConfig extends \CodeIgniter\Config\BaseConfig
{
	public $QZERO;
	public $QZEROSTR;
	public $QEMPTYSTR;
	public $QFALSE;

	public $first = 'foo';
	public $second = 'bar';

	public $FOO;
	public $onedeep;

	public $default = [
		'name' => null
	];

	public $simple = [
		'name' => null
	];
}
