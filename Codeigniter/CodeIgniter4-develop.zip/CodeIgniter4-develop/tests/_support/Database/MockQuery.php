<?php namespace CodeIgniter\Database;

class MockQuery extends Query
{
	
}
