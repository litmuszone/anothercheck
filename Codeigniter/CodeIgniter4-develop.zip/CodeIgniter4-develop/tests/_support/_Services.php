<?php namespace CodeIgniter;

/**
 * Class Services
 *
 * This class is only for IDE auto completion. We don't load this file.
 *
 * @package CodeIgniter
 */
class Services extends \Config\Services {}
